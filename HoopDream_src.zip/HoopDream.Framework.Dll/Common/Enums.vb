﻿Namespace HoopDream.Framework

    Public Enum EntityType As Integer
        Items
        Players
        Positions
        Reports
        Rosters
        Teams
    End Enum

End Namespace
