﻿

Namespace HoopDream
    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(New FormMain())
        End Sub
    End Class
End Namespace
