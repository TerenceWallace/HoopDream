

Namespace HoopDream.Common

    Friend Class FilterEventArgs
        Inherits System.EventArgs

        Public Property Criteria() As String

        Public Property ColumnName As String

    End Class
End Namespace
